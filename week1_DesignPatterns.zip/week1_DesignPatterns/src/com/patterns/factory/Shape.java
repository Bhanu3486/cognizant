package com.patterns.factory;

public interface Shape {
    void draw();

}
