/**
 * 
 */
/**
 * 
 */
module week1_DesignPatterns {
}